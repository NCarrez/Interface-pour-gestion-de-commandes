
#include <touchgfx/Font.hpp>

#ifndef NO_USING_NAMESPACE_TOUCHGFX
using namespace touchgfx;
#endif

FONT_LOCATION_FLASH_PRAGMA
KEEP extern const touchgfx::GlyphNode glyphs_verdana_40_4bpp[] FONT_LOCATION_FLASH_ATTRIBUTE = {
 {     0,  32,   0,   0,   0,   0,  14, 255,   0, 0},
 {     0,  50,  20,  31,  31,   3,  25, 255,   0, 0},
 {   310,  63,  17,  31,  31,   3,  22, 255,   0, 0},
 {   574, 120,  22,  22,  22,   1,  24, 255,   0, 0}
};

